<?php

namespace Intervention\Image\Exception;

class NotSupportedException extends \RuntimeException
{
    # nothing to override
}
