<?php

namespace Intervention\Image\Exception;

class NotWritableException extends \RuntimeException
{
    # nothing to override
}
