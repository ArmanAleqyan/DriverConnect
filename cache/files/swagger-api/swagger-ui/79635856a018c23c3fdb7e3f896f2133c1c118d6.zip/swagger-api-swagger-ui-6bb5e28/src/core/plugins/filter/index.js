import opsFilter from "./opsFilter"

export default function() {
  return {
    fn: {
      opsFilter
    }
  }
}
