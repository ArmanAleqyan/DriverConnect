/**
 * @prettier
 */
const iriReferenceGenerator = () => "path/실례.html"

export default iriReferenceGenerator
